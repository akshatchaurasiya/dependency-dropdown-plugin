<?php
$string['pluginname'] = 'Dependency';
$string['submit'] = 'Submit';
