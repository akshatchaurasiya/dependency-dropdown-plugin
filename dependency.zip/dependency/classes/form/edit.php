<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Rates form
 *
 * @package    local_ajaxdemoform
 * @copyright  2020 Ricoshae Pty Ltd
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

 require_once("$CFG->libdir/formslib.php");

 class edit extends moodleform
{
    //Add elements to form
    public function definition()
    {
        global $CFG,$DB;

        $mform = $this->_form; // Don't forget the underscore!
        // $mform->addElement('html', '<h2>Dependency dropdown form </h2><br><br>');

        $mform->addElement('hidden','id');
        $mform->setType('id', PARAM_INT);

        

        $countries = $DB->get_records('local_country',null);
        $options= [];
        $options[-1]= 'Select Country';
        foreach($countries AS $country) {
        $options[$country->id] = $country->country;
        }

        $mform->addElement('select', 'country', 'Country', $options); // Add elements to your form
        $mform->setType('country', PARAM_INT);                   //Set type of element
        $mform->setDefault('country', -1);        //Default value

        $options= [];
        $options[]= 'Select State';
        $mform->addElement('select', 'state', 'State', $options); // Add elements to your form
        $mform->setType('state', PARAM_INT);                   //Set type of element
        $mform->setDefault('country', -1);        //Default value

        $mform->addElement('hidden', 'stateid'); // Add elements to your form
        $mform->setType('stateid', PARAM_INT);                   //Set type of element
        $mform->setDefault('stateid', -1);        //Default value

        $options= [];
        $options[]= 'Select District';
        $mform->addElement('select', 'district', 'District', $options); // Add elements to your form
        $mform->setType('district', PARAM_INT);                   //Set type of element
        $mform->setDefault('state', -1);        //Default value

        $mform->addElement('hidden', 'districtid'); // Add elements to your form
        $mform->setType('districtid', PARAM_INT);                   //Set type of element
        $mform->setDefault('stateid', -1);        //Default value

        $buttonarray=array();
        $buttonarray[] = $mform->createElement('submit', 'Submit', 'Save');
        $buttonarray[] = $mform->createElement('cancel');
        $mform->addgroup($buttonarray, 'buttonar', '', ' ', false);

    }

    //Custom validation should be added here
    public function validation($data, $files){
        if ($data['country'] == '-1' && $data['country'] == '0'){
                $errors['country'] = get_string('conerr', 'local_dependency');
            }

        return $errors;
    }

  }
