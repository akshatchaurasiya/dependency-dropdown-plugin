//
// * Javascript
// *
// * @package    ajaxdemo
// * Developer: 2020 Ricoshae Pty Ltd (http://ricoshae.com.au)
//

require(['core/first', 'jquery', 'jqueryui', 'core/ajax'], function(core, $, bootstrap, ajax) {

  // -----------------------------
  $(document).ready(function() {

    //  toggle event
    $('#id_country').change(function() {
      // get current value then call ajax to get new data
      var selectedcourseid = $('#id_country').val();
      ajax.call([{
        methodname: 'local_dependency_getstate',
        args: {
          'id': selectedcourseid
        },
      }])[0].done(function(response) {
        // clear out old values
        $('#id_state').html('');
        $('#id_district').html('');
        var data = JSON.parse(response);
        $('<option/>').html('Select State').appendTo('#id_state');
        $('<option/>').html('Select District').appendTo('#id_district');
        for (var i = 0; i < data.length; i++) {
          $('<option/>').val(data[i].id).html(data[i].state).appendTo('#id_state');
        }
        setnewvalue();
        return;
      }).fail(function(err) {
        console.log(err);
        //notification.exception(new Error('Failed to load data'));
        return;
      });

    });

    $('#id_state').change(function() {
      setnewvalue();
    });

    function setnewvalue() {
      console.log($('#id_state').val());
      $('input[name = stateid]').val($('#id_state ').val());
    }

  });
  // District
  $(document).ready(function() {

    //  toggle event
    $('#id_state').change(function() {
      // get current value then call ajax to get new data
      var selectedcourseid = $('#id_state').val();
      $('#id_district').html('');
      $('<option/>').html('Select District').appendTo('#id_district');
      ajax.call([{
        methodname: 'local_dependency_getdistrict',
        args: {
          'id': selectedcourseid
        },
      }])[0].done(function(response) {data
        // clear out old values
        $('#id_district').html('');
        var data = JSON.parse(response);
        $('<option/>').html('Select District').appendTo('#id_district');
        for (var i = 0; i < data.length; i++) {
          $('<option/>').val(data[i].id).html(data[i].district).appendTo('#id_district');
        }
        setnewvalue();
        return;
      }).fail(function(err) {
        console.log(err);
        //notification.exception(new Error('Failed to load data'));
        return;
      });

    });

    $('#id_district').change(function() {
      setnewvalue();
    });

    function setnewvalue() {
      console.log($('#id_district').val());
      $('input[name = districtid]').val($('#id_district ').val());
    }

  });
});