<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.


require_once(__DIR__ . '/../../config.php');
global $USER, $DB, $CFG;
require_login();
require_once($CFG->dirroot . '/local/dependency/classes/form/edit.php');
$PAGE->set_url(new moodle_url('/local/dependency/index.php'));
$PAGE->set_context(context_system::instance());
$PAGE->requires->js('/local/dependency/assets/js_dependency.js');
$PAGE->set_title('Edit');
$PAGE->set_heading('Dependency dropdown');
$PAGE->navbar->add('Index', new moodle_url('/local/dependency/index.php'));


// get id if editing form
$id = optional_param('id', '', PARAM_TEXT);
$delete = optional_param('delete', 0, PARAM_INT);
$teachers = optional_param('teachers', -1, PARAM_INT);



// form block code for display form
$mform = new edit();

if ($mform->is_cancelled()) {
    // Go back to index.php page
    redirect($CFG->wwwroot.'/local/dependency/index.php', 'You cancelled the form');
}
else if ($fromform = $mform->get_data()) {
  // Insert the data into our database table.
  $recordtoinsert = new stdClass();
  $recordtoinsert->country = $fromform->country;
  $recordtoinsert->state = $fromform->stateid;
  $recordtoinsert->district = $fromform->districtid;
  // print_r($recordtoinsert);
  // die;

  $DB->insert_record('local_dependency', $recordtoinsert);

  // Go back to index.php page
  redirect($CFG->wwwroot.'/local/dependency/index.php', 'Your data successfully saved');

 }

echo $OUTPUT->header();
$mform->display();
echo $OUTPUT->footer();
