<?php

// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External Web Service Template
 *
 * @package    services
 * Developer: 2020 Ricoshae Pty Ltd (http://ricoshae.com.au)
 */

// We defined the web service functions to install.
$functions = array(
         'local_dependency_getstate' => array(
                'classname'   => 'local_dependency_external',
                'methodname'  => 'getstate',
                'classpath'   => 'local/dependency/externallib.php',
                'description' => 'Return state in a country',
                'type'        => 'read',
                'ajax' => true,
                'capabilities' => '',
                'loginrequired' => true
//                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)
          ),
         'local_dependency_getdistrict' => array(
                'classname'   => 'local_dependency_external',
                'methodname'  => 'getdistrict',
                'classpath'   => 'local/dependency/externallib.php',
                'description' => 'Return district in a state',
                'type'        => 'read',
                'ajax' => true,
                'capabilities' => '',
                'loginrequired' => true
//                'services' => array(MOODLE_OFFICIAL_MOBILE_SERVICE)
          )
);
