require(['core/first','jquery','jqueryui','core/ajax']
function(core,$,bootstrap,ajax){
       $(document).ready(function(){
        $('#id_courses').change(function(){
                var selectedcourseid = $('#id_courses').val();
                ajax.call([{
                        methodname: 'local_ajexdemo_getteachersincourse',
                        args:{
                                'id:selectedcourseid'
                        }''
                }])[0].done(function(response){
                        $('#id_teachers').html('');
                        var data = JSON.parse(response);
                        for(var i = 0; i < data.length; i++){
                                $('<option/>').val(data[i].id).html(data[i].firstname).appendTo('#id_teachers');
                        }
                        return;
                }).fail(function(err){
                        console.log(err);
                        return;
                });
        });
       }) ;
});