<?php


defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/externallib.php');


class local_ajaxdemo_external extends external_api{

    public static function getteacherincourse_parameters()
    {
        return new external_function_parameters(array("id" => new external_value(PARAM_INT,"id"))
    );
    }
    public static function getteacherincourse($id)
    {
        global $USER, $DB, $CFG;

        $params = $DB->get_record('role', array('shortname'=>'editingteacher'));
        $context = CONTEXT_COURSE::instance($id);
        $teacher = get_enrolled_users($role->id,$context,true);
        return json_encode(array_values($teachers));
    }

    /*public static function getteacherincourse_re{
        return new external_value(PARAM_RAW,'the'){

        }
    }*/

};