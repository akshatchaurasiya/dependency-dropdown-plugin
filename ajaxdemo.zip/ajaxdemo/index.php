<?php
	require_once(__DIR__. '/../../config.php');
	require_once($CFG->dirroot . '/local/ajaxdemo/forms/ajaxdemo_form.php');
	global $DB, $CFG, $PAGE,$USER;

	$context = context_system::instance();
	$PAGE->set_url(new moodle_url('/local/ajaxdemo/index.php'));
	// $PAGE->requires->js('local/ajaxdemo/assets/js_ajaxdemo.js');
	$PAGE->set_context(context_system::instance());
	

	// require_login();

	// $id = optional_param('id','','PARAM_TEXT')

	// $obj = new stdClass();

	$PAGE->set_title('index');
	$PAGE->set_heading("Ajaxdemo");
	
	$mform = new ajaxdemo_form();
	// $toform = [];

	// if($mform->is_cancelled()){
	// 	redirect('/','',10);
	// }else if($fromform = $mform->getdata()){

	// }

	echo $OUTPUT->header();
	
	$mform->display();

	echo $OUTPUT->footer();
