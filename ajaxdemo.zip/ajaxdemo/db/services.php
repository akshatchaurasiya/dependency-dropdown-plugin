<?php
 defined('MOODLE_INTERNAL') || die();
$functions = array(

	 'local_ajaxdemo_getteachersincourse' => array( // local_PLUGINNAME_FUNCTIONNAME is the name of the web service function that the client will call.
                'classname'   => 'local_ajaxdemo_external', // create this class in componentdir/classes/external
                'classpath'   => 'local_/ajaxdemo/externallib.php',
                'methodname'  => 'getteachersincourse', // implement this function into the above class
                'description' => 'return techers in a course',
                'type'        => 'read', // the value is 'write' if your function does any database change, otherwise it is 'read'.
                'ajax'        => true, // true/false if you allow this web service function to be callable via ajax
                'loginrequired' => true,
                'capabilities'  => ''

        )
    );