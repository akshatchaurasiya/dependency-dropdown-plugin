<?php

// namespace local_ajaxdemo\form;
require_once("$CFG->libdir/formslib.php");

    use core;
    use moodleform;
    use context_system;

class ajaxdemo_form extends moodleform {
    public function definition() {
        global $CFG,$DB;
       
        
        $mform = $this->_form;
        $mform->addElement('html','<h2>ajax demo form</h2>');


        $cocat = $DB->get_records('course',null);
        $opt = [];
        
        foreach($cocat as $cat){
            $opt[$cat->id] = $cat->fullname;
        }
        $mform->addElement('select', 'course', get_string('coursecategory','local_prjtwo'), $opt);
        
        $opt=[];
        $mform->addElement('select', 'teachers', get_string('coursecategory','local_prjtwo'), $opt);


        $this->add_action_buttons();

    }
    
}