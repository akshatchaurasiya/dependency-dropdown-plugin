<?php
$string['pluginname'] = 'ajaxdemo';